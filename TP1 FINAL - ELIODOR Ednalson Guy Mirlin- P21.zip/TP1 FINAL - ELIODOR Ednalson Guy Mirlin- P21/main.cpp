//////////////////////////////////////////////////////////////////////////////
//									    //
//				Fichier  : main.cpp			    //
//			Author : ELIODOR Ednalson Guy Mirlin (P21)	    //
//									    //
//				Date : 01/17/2017  			    //
//			   Programme : TP Affichage 2D			    //
//									    //
//////////////////////////////////////////////////////////////////////////////

#include <SDL.h>
#include <math.h>
#include <stdio.h>
#include <unistd.h>
#include <stdbool.h>


///////////////////////////////////////////
// Fenêtre SDL
///////////////////////////////////////////
SDL_Surface *fenetre; // Fenêtre d'affichage SDL
int BytePP = 4;       // Nombre d'octets par pixel
int PROF = 32;        // Nombre de bits par pixel
int LARGEUR = 1000;    // Largeur par défaut de la fenêtre
int HAUTEUR = 800;    // Hauteur par défaut de la fenêtre
int MARGE = 75;       // Marge entre bord écran et fenêtres image
int EXO = 0;          // Selection d'exercice à affichier

///////////////////////////////////////////
// Type pour une couleur
///////////////////////////////////////////
typedef unsigned char octet; // Codage d'une composante
// de base sur un octet
typedef struct               // Structure de couleur
{
    octet R, V, B ;            // composée des 3 bases
} TCouleur ;                 // Nom du type couleur

///////////////////////////////////////////
// Types de points et de segments
///////////////////////////////////////////
typedef struct               // Structure d'un point image
{
    int col, lig;              // Coordonnées colonne et ligne dans l'image
} TPointImage;

typedef struct               // Structure d'un point réel
{
    double x, y;               // Coordonnées x et y dans le plan réel
} TPointReel;

typedef struct               // Structure d'un segment réel
{
    TPointReel p1, p2;         // Points extrémités du segment
} TSegmentReel;

typedef struct               // Structure d'un segment d'image
{
    TPointImage p1, p2;         // Points extrémités du segment
} TSegmentImage;


typedef struct               // Structure d'une fenêtre image
{
    TPointImage bg, hd;        // Points bas-gauche et haut-droit délimitant la fenêtre
} TFenetreImage;

typedef struct               // Structure d'un segment réel
{
    TPointReel bg, hd;         // Points bas-gauche et haut-droit délimitant la fenêtre
} TFenetreReel;

typedef struct               // Structure contenant les infos de transfo du plan réel vers l'image
{
    TFenetreReel fr;           // Fenêtre du plan réel
    TFenetreImage fi;          // Fenêtre dans l'image
    double A, B, C, D;         // Coefficients de transformation réel -> image
} TReelVersImage;

///////////////////////////////////////////
// Coloriage du pixel (x,y) avec la couleur C
///////////////////////////////////////////
void ColoriePixel (int x, int y, TCouleur C)
{
    // Tests SDL pour l'affichage (hors cadre du cours)
    if(!SDL_MUSTLOCK(fenetre) || SDL_LockSurface(fenetre) >= 0)
    {
        // Tests de validité de la position (x,y) -> à l'intérieur de la fenêtre
        if(x>=0 && x<fenetre->w && y>=0 && y<fenetre->h)
        {
            // Affichage du pixel en SDL avec la couleur spécifiée (hors cadre du cours)
            Uint8 *pixmem32 = (Uint8*) fenetre->pixels  + y * fenetre->pitch + x * BytePP;
            *(Uint32 *)pixmem32 = SDL_MapRGB(fenetre->format, C.R, C.V, C.B);
        }
    }
    // Test et action de fin d'affichage SDL (hors cadre du cours)
    if(SDL_MUSTLOCK(fenetre))
    {
        SDL_UnlockSurface(fenetre);
    }
}

///////////////////////////////////////////
// Colorie tous les pixels en noir ("vide" la fenêtre)
///////////////////////////////////////////
void EffacerTout ()
{
    // Tests SDL pour l'affichage (hors cadre du cours)
    if(!SDL_MUSTLOCK(fenetre) || SDL_LockSurface(fenetre) >= 0)
    {
        SDL_FillRect(fenetre, NULL, 0x000000);
    }
    // Test et action de fin d'affichage SDL (hors cadre du cours)
    if(SDL_MUSTLOCK(fenetre))
    {
        SDL_UnlockSurface(fenetre);
    }
}

/******************************************/
/*              EXERCICE 1                */
/******************************************/

///////////////////////////////////////////
// Tracer d'un segment image
///////////////////////////////////////////

void DessineSegmentImage(TPointImage p1, TPointImage p2, TCouleur coul)
{
    // Accès à la colonne du point p1 par : p1.colonne
    // et ainsi de suite pour les autres coordonnées...

    double deltaX = 0.0, deltaY = 0.0;
    int signe = 1; //donc le sens de la droite suivant les coordonnees des deux points
    int colonne, ligne;
    
   //Calcul de dx et dy
   //comme pour une droite simple tel p1(xp1, yp1) et p2(xp2, yp2) on a deltaX=xp2-xp1 et deltaY=yp2-yp1
   //or ici p1(p1.col, p1.lig) et p2(p2.col, p2.lig) donc le calcul de deltaX et deltaY s'effectue comme suit :
    deltaX = p2.col - p1.col;
    deltaY = p2.lig - p1.lig;

    //Position courante
    int ligneEnCours  = p1.lig;
    int colonneEnCours  = p1.col;

  /*

    \     |     /
     \    |    /
      \   |   /
       \  |  /     
        \ | /  
         \|/
   -----------------
         /|\
        / | \  
       /  |  \
      /   |   \    
     /    |    \
    /     |     \
*/

    //cas horizontal
    //contrairement au cas vertical ici la diference (deltaY= p2.lig - p1.lig) est egal a zero
    if (deltaY == 0)
    {
        //condition sur le signe par rapport a deltaX
        if (deltaX<0){
		     signe=-1;
                 }
         else {
		signe=1;
	      }

        while(colonneEnCours != (p2.col+signe))
        {

            ColoriePixel(colonneEnCours,p2.lig,coul); //appel a la fonction void ColoriePixel (int x, int y, TCouleur C) pour allumer le pixel

            colonneEnCours = colonneEnCours+signe; 

        }

    }

    //cas vertical
    //avec (p2.col - p1.col)=0 notre ligne sera vertical ie dx=0 et dy different de zero
    if (deltaX == 0)
    {
        //consition sur le signe par rapport a dy
        if (deltaY<0){
		     signe=-1;
                    }
         else {
		signe=1;
	      }
        //la variable signe est donc egal a  dy ie abs(dy);

        while(ligneEnCours != (p2.lig+signe))
        {

            ColoriePixel(p2.col,ligneEnCours,coul); //appel a la fonction void ColoriePixel (int x, int y, TCouleur C)

            ligneEnCours =ligneEnCours+signe;

        }

    }

    //cas particulier la droite n'est ni horizontale ni verticale
    if ((deltaX != 0) && (deltaY != 0)) 
    {
        
        double m = deltaY / deltaX; //m : pente, donc calcul de la pente. 

        double b = (double)p1.lig - m * (double)p1.col; // avec y=mx+b ==> b=y-mx

        if(abs(m) >1) // cas ou m en valeur absolue est > a 1 (au dessus de 45 deg)
        {
            //condition sur le signe par rapport a dy
        if (deltaY<0){
		     signe=-1;
                    }
         else {
		signe=1;
	      }
            while(ligneEnCours != (p2.lig+signe))
            {

                ColoriePixel(colonneEnCours,ligneEnCours,coul); //appel a la fonction void ColoriePixel (int x, int y, TCouleur C)
                ligneEnCours =ligneEnCours + signe;
                colonneEnCours = (int)( ((double)ligneEnCours - b)/m); //conversion en type int du calcul 
            }

        }

        else//if(abs(m : pente) <1)
        {
            
            //condition sur le signe par rapport a dx
        if (deltaX<0){
		     signe=-1;
                 }
         else {
		signe=1;
	      }
            
            while( colonneEnCours != (p2.col+signe))
            {

                ColoriePixel(colonneEnCours,ligneEnCours,coul);
                colonneEnCours = colonneEnCours+signe;
                ligneEnCours = (int)(m*colonneEnCours + b);
            }

        }


    }
   
}

///////////////////////////////////////////
// Fonction principale d'affichage d'exercise 1
///////////////////////////////////////////
void AffichagePrincipal_EXO1 ()
{   
    TCouleur couleurSegment = {200, 150, 250};    // Couleur de dessin des segments
    TCouleur colorPoint = {255, 255, 0};          // Couleur de dessin des points
    
    //Droite passant par p1 et p2
    TPointImage p1 = {40, 40}; //coordonnees du point p1
    TPointImage p2 = {550, 300}; //coordonnees du point p2
    DessineSegmentImage(p1,p2,couleurSegment); //tracage du premier segment 
    
    //Droite passant par p3 et p4
    TPointImage p3 = {650, 370}; //coordonees du point p3
    TPointImage p4 = {375, 500}; //coordonnees du points p4
    //tracage du 2e segment
    DessineSegmentImage (p3,p4, couleurSegment);
   
    //Droite passant par p5 et p6
    TPointImage p5 = {500, 375}; //coordonnees du point p5
    TPointImage p6 = {370, 100}; //coordonnees du point p6
    //tracage du 3e segment
    DessineSegmentImage (p5,p6, couleurSegment);
    

    // Mise à jour de l'affichage de la fenêtre SDL (hors cadre du cours)
    SDL_Flip(fenetre);
}
/******************************************/
/*              EXERCICE 2                */
/******************************************/
///////////////////////////////////////////
// Tracer les contours de la fenêtre d'image
///////////////////////////////////////////
void DessineContoursImage(TFenetreImage fi, TCouleur coul)
{
    // Points image pour les coins de la fenêtre
    //avec fi : fenetre image; bg : en bas a gauche; hd : en haut a droite
    TPointImage pi1 = {fi.bg.col,fi.hd.lig}; 
    TPointImage pi2 = {fi.bg.col,fi.bg.lig};
    TPointImage pi3 = {fi.hd.col,fi.bg.lig};
    TPointImage pi4 = {fi.hd.col,fi.hd.lig};

    /*
     -|-------------------------->
      | - |------------------|-fi.hd
      |   | p1             p4|
      |   |                  |
      |   |                  |
      |   |                  |
      |   |                  |
      |   |                  |
      |   |p2              p3|
      | - |------------------|-
      |fi.bg 

    */
    //Dessinons les 4 segments
    //avec pi: point image
    DessineSegmentImage (pi2, pi1,coul); //segment de pi1 a pi2
    DessineSegmentImage (pi1, pi4,coul); //segment de pi1 a pi4
    DessineSegmentImage (pi4, pi3,coul);//segment de pi4 a pi3
    DessineSegmentImage (pi3, pi2,coul);//segment de pi3 a pi2

}

void DessineSegmentFenetre(TPointImage p1, TPointImage p2, TCouleur coul, TFenetreImage fi)
{
    // Accès à la colonne du point p1 par : p1.col
    // et ainsi de suite pour les autres coordonnées...
    TPointImage p1temp, p2temp;
    
    p1temp.lig = p1.lig + fi.hd.lig;
    p1temp.col = p1.col + fi.bg.col;

    p2temp.lig = p2.lig + fi.hd.lig;
    p2temp.col = p2.col + fi.bg.col;

    DessineSegmentImage (p1temp, p2temp,coul);
   
}

///////////////////////////////////////////
// Tracer d'un triangle dans l'image
///////////////////////////////////////////
void DessineTriangleFenetre(TPointImage p1, TPointImage p2, TPointImage p3, TCouleur coul, TFenetreImage fi)
{
    //Triangle : 3 segment reliant p1 a p2, p2 a p3, p3 a p1
    DessineSegmentFenetre(p1, p2, coul, fi); //segment de droite reliant le 1er point au 2eme point
    DessineSegmentFenetre(p2, p3, coul, fi); //segment de droite reliant le 2eme point au 3eme point
    DessineSegmentFenetre(p3, p1, coul, fi); //segment de droite reliant le 3eme point au 1er point


}

///////////////////////////////////////////
// Fonction principale d'affichage d'exercise 2
///////////////////////////////////////////
void AffichagePrincipal_EXO2 ()
{

    TCouleur couleurContour = {255, 0, 0};        // Couleur du contour de la fenêtre image (rouge)
    TCouleur colorPoint = {255, 255, 0};          // Couleur de dessin des points
    TCouleur couleurTriangle1 = {200, 150, 250};    // Couleur de dessin de 1er triangle
    TCouleur couleurTriangle2 = {10, 10, 250};    // Couleur de dessin des 2er triangle

    // Affichage du contour de la fenêtre image (les 4 côtés) en utilisant le dessin de segments image et la couleurContour
    int minDim = HAUTEUR;
    if (minDim > LARGEUR)
        minDim = LARGEUR;
    TFenetreImage fi = { {MARGE, minDim-MARGE}, {minDim-MARGE,MARGE} };

    
    // Affichage les contours d'images
    DessineContoursImage(fi, couleurContour);//appel a la fonction DessineContoursImage
    

    // Affichage d'un triangle dans l'image
    TPointImage p1 = {100, 10};
    TPointImage p2 = {550, 300};
    TPointImage p3 = {375, 500};

    DessineTriangleFenetre( p1,  p2,  p3,  couleurTriangle1,  fi);
    ColoriePixel(p1.col+ fi.bg.col,p1.lig+ fi.hd.lig,colorPoint);
    ColoriePixel(p2.col+ fi.bg.col,p2.lig+ fi.hd.lig,colorPoint);
    ColoriePixel(p3.col+ fi.bg.col,p3.lig+ fi.hd.lig,colorPoint);


    // Affichage d'un triangle dans l'image
    TPointImage q1 = {259, 430};
    TPointImage q2 = {603, 301};
    TPointImage q3 = {216, 129};

    DessineTriangleFenetre( q1,  q2,  q3,  couleurTriangle2,  fi);
    ColoriePixel(q1.col+ fi.bg.col,q1.lig+ fi.hd.lig,colorPoint);
    ColoriePixel(q2.col+ fi.bg.col,q2.lig+ fi.hd.lig,colorPoint);
    ColoriePixel(q3.col+ fi.bg.col,q3.lig+ fi.hd.lig,colorPoint);


    // Mise à jour de l'affichage de la fenêtre SDL (hors cadre du cours)
    SDL_Flip(fenetre);
}

/******************************************/
/*              EXERCICE 3                */
/******************************************/

///////////////////////////////////////////
// Découpage d'un segment image par rapport à la fenêtre d'image
///////////////////////////////////////////
TSegmentImage DecoupageSegmentImage(TSegmentImage seg, TFenetreImage fi)
{
    TSegmentImage resultat, cp_resultat;
    char gauche1, dessus1, droite1, dessous1;
    char gauche2, dessus2, droite2, dessous2;
    char toutDehors = 0, toutDedans = 0;
    double deltaX = 0.0;
    double deltaY = 0.0;
    double m = 0.0;
    double b = 0.0;

    //y= mx + b ==> b= y - mx
    //m = dy / dx

    // Recopie du segment initial dans la variable de travail
    resultat = seg;

    //en utilisant les variables resultat et cp_resultat on aura:
    cp_resultat.p1.col = resultat.p1.col + fi.bg.col;
    cp_resultat.p1.lig = resultat.p1.lig + fi.hd.lig;

    cp_resultat.p2.col = resultat.p2.col + fi.bg.col;
    cp_resultat.p2.lig = resultat.p2.lig + fi.hd.lig;

    deltaX = cp_resultat.p2.col - cp_resultat.p1.col; 
    deltaY = cp_resultat.p2.lig - cp_resultat.p1.lig;

    if (deltaX != 0 && deltaY != 0)
    {
        m = deltaY / deltaX;

        b = (double)cp_resultat.p1.lig - m * (double)cp_resultat.p1.col; //y = mx + b ==> b= y - mx
    }

    // Initialisation des informations de localisation des extrémités
    //test d'exclusion p1
    gauche1 = cp_resultat.p1.col < fi.bg.col ? 1 : 0; 
    droite1 = cp_resultat.p1.col > fi.hd.col ? 1 : 0;
    dessus1 = cp_resultat.p1.lig < fi.hd.lig ? 1 : 0;
    dessous1 = cp_resultat.p1.lig > fi.bg.lig ? 1 : 0;

    //test d'exclusion p1
    gauche2 = cp_resultat.p2.col < fi.bg.col ? 1 : 0;
    droite2 = cp_resultat.p2.col > fi.hd.col ? 1 : 0;
    dessus2 = cp_resultat.p2.lig < fi.hd.lig ? 1 : 0;
    dessous2 = cp_resultat.p2.lig > fi.bg.lig ? 1 : 0;


    // Boucle de projection des extrémités sur les bords de la fenêtre
    do
    {
        if((gauche1 && gauche2) || (dessus1 && dessus2) || (droite1 && droite2) || (dessous1 && dessous2))
        {
            toutDehors = 1;
            // on est dans ce cas ou les deux points pour notre segment est a l'exterieur de notre fenetre image
            
    /*
     -|---------------------------------------->
      |                 dessus
      |       --|------------------|-fi.hd
      |         |                  |
      |         |                  |
      |         |                  | 
      |  Gauche |                  | Droite
      |         |                  |
      |         |                  |
      |         |                  |
      |       --|------------------|-
      |      fi.bg      Dessous
      |         
      |         
                
    */
            
        }
        else
        {
            if(!gauche1 && !gauche2 && !dessus1 && !dessus2 && !droite1  && !droite2 && !dessous1 && !dessous2)
            {
                toutDedans = 1;
                
      // on est dans ce cas ou les deux points pour notre segment est a l'exterieur de notre fenetre image
            
    /*
     -|---------------------------------------->
      |                 dessus
      |       --|-----------------------|-fi.hd
      |         |                       |
      |         |                       |
      |         |   .-------------.     | 
      |  Gauche | p1               p2   | Droite
      |         |                       |
      |         |                       |
      |         |                       |
      |       --|-----------------------|-
      |      fi.bg      Dessous
      |         
      |         
                
    */
            }
            else
            {
                if(gauche1)
                {
                    // on est dans ce cas ou notre point p1 se trouve a l'exterieur gauche de la fenetre image
                   // Déplacons p1 sur la droite verticale issue du bord gauche de la fenêtre
                   // Mise à jour des indicateurs de position
            
    /*
     -|---------------------------------------->
      |                 dessus
      |       --|-----------------------|-fi.hd
      |         |                       |
      |         |                       |
      |   .-----|-------------.         | 
      |  p1     |              p2       | Droite
      |         |                       |
      |   Gauche|                       |
      |         |                       |
      |       --|-----------------------|-
      |      fi.bg      Dessous
      |         
      |         
                
    */

                    cp_resultat.p1.col = fi.bg.col;


                    if (deltaX != 0 && deltaY != 0)
                    {

                        cp_resultat.p1.lig = (int)(m* cp_resultat.p1.col + b);

                    }

                    gauche1 = 0;



                }
                else
                {
                    if(dessus1)
                    {
                        // Déplace p1 sur la droite horizontale issue du bord haut de la fenêtre
                    
                        // Mise à jour des indicateurs de position
                        
 /*
     -|---------------------------------------->
      |                 .p1
      |                 |
      | 		|
      |                 |      dessus
      |       --|-------|---------------|-fi.hd
      |         |       |               |
      |         |       |               |
      |         |       |               | 
      |         |       . p2            | Droite
      |         |                       |
      |   Gauche|                       |
      |         |                       |
      |       --|-----------------------|-
      |      fi.bg      Dessous
      |         
      |         
                
    */

                        cp_resultat.p1.lig = fi.hd.lig;


                        if (deltaX != 0 && deltaY != 0)
                        {

                            cp_resultat.p1.col = (int)( ((double)cp_resultat.p1.lig - b)/m);

                        }

                        dessus1 = 0;


                    }
                    else
                    {
                        if(droite1)
                        {
                            // Déplace p1 sur la droite verticale issue du bord droit de la fenêtre
                           
                            // Mise à jour des indicateurs de position
  /*
     -|---------------------------------------->
      |                 dessus
      |       --|-----------------------|-fi.hd
      |         |                       |
      |         |                       |
      |         |             .---------|---------. 
      |         |             p2        | Droite  p1
      |         |                       |
      |   Gauche|                       |
      |         |                       |
      |       --|-----------------------|-
      |      fi.bg      Dessous
      |         
      |         
                
   */

                            cp_resultat.p1.col = fi.hd.col;

                            if (deltaX != 0 && deltaY != 0)
                            {

                                cp_resultat.p1.lig = (int)(m* cp_resultat.p1.col + b);

                            }

                            droite1 = 0;


                        }
                        else
                        {
                            if(dessous1)
                            {
                                // Déplace p1 sur la droite horizontale issue du bord bas de la fenêtre
                                
                                // Mise à jour des indicateurs de position
 /*
     -|---------------------------------------->              		
      |                  dessus
      |       --|-----------------------|-fi.hd
      |         |                       |
      |         |                       |
      |         |                       | 
      |         |       . p2            | Droite
      |         |       |               |
      |   Gauche|       |               |
      |         |       |               |
      |       --|-------|---------------|-
      |      fi.bg      |  Dessous
      |                 |
      |                 . p1
                
    */
                                
                                cp_resultat.p1.lig = fi.bg.col ;

                                if (deltaX != 0 && deltaY != 0)
                                {

                                    cp_resultat.p1.col = (int)( ((double)cp_resultat.p1.lig - b)/m);

                                }

                                dessous1 = 0;



                            }
                            else
                            {
                                if(gauche2)
                                {
                                    // Déplace p2 sur la droite verticale issue du bord gauche de la fenêtre
                                    
                                    // Mise à jour des indicateurs de position
                                    
/*
     -|---------------------------------------->
      |                 dessus
      |       --|-----------------------|-fi.hd
      |         |                       |
      |         |                       |
      |   .-----|-------------.         | 
      |  p2     |              p1       | Droite
      |         |                       |
      |   Gauche|                       |
      |         |                       |
      |       --|-----------------------|-
      |      fi.bg      Dessous
      |         
      |         
                
    */
                                    cp_resultat.p2.col = fi.bg.col;


                                    if (deltaX != 0 && deltaY != 0)
                                    {

                                        cp_resultat.p2.lig = (int)(m* cp_resultat.p2.col + b);

                                    }
                                    gauche2 = 0;


                                }
                                else
                                {
                                    if(dessus2)
                                    {
                                        // Déplace p2 sur la droite horizontale issue du bord haut de la fenêtre
                                        
                                        // Mise à jour des indicateurs de position
                                        
/*
     -|---------------------------------------->
      |                 .p2
      |                 |
      | 		|
      |                 |      dessus
      |       --|-------|---------------|-fi.hd
      |         |       |               |
      |         |       |               |
      |         |       |               | 
      |         |       . p1            | Droite
      |         |                       |
      |   Gauche|                       |
      |         |                       |
      |       --|-----------------------|-
      |      fi.bg      Dessous
      |         
      |         
                
    */
                                        cp_resultat.p2.lig = fi.hd.lig;


                                        if (deltaX != 0 && deltaY != 0)
                                        {

                                            cp_resultat.p2.col = (int)( ((double)cp_resultat.p2.lig - b)/m);

                                        }
                                        dessus2 = 0;


                                    }
                                    else
                                    {
                                        if(droite2)
                                        {
                                            // Déplace p2 sur la droite verticale issue du bord droit de la fenêtre
                                            
                                            // Mise à jour des indicateurs de position
   /*
     -|---------------------------------------->
      |                 dessus
      |       --|-----------------------|-fi.hd
      |         |                       |
      |         |                       |
      |         |             .---------|---------. 
      |         |             p1        | Droite  p2
      |         |                       |
      |   Gauche|                       |
      |         |                       |
      |       --|-----------------------|-
      |      fi.bg      Dessous
      |         
      |         
                
   */                                         

                                            cp_resultat.p2.col = fi.hd.col;

                                            if (deltaX != 0 && deltaY != 0)
                                            {

                                                cp_resultat.p2.lig = (int)(m* cp_resultat.p2.col + b);

                                            }
                                            droite2 = 0;

                                        }
                                        else
                                        {
                                            if(dessous2)
                                            {
                                                // Déplace p2 sur la droite horizontale issue du bord bas de la fenêtre
                                                
                                                // Mise à jour des indicateurs de position
/*
     -|---------------------------------------->              		
      |                  dessus
      |       --|-----------------------|-fi.hd
      |         |                       |
      |         |                       |
      |         |                       | 
      |         |       . p1            | Droite
      |         |       |               |
      |   Gauche|       |               |
      |         |       |               |
      |       --|-------|---------------|-
      |      fi.bg      |  Dessous
      |                 |
      |                 . p2
                
    */
                                                
                                                cp_resultat.p2.lig = fi.bg.col ;

                                                if (deltaX != 0 && deltaY != 0)
                                                {

                                                    cp_resultat.p2.col = (int)( ((double)cp_resultat.p2.lig - b)/m);

                                                }
                                                dessous2 = 0;



                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    while(!toutDehors && !toutDedans);

    // Affectation des extrémités du segment final HORS de la fenêtre réelle
    // pour indiquer à la fonction appelante que le segment N'est PAS valide
    if(toutDehors)
    {
        resultat.p1.col = fi.bg.col-1.0;
        resultat.p1.lig = fi.bg.lig-1.0;
        resultat.p2.col = fi.bg.col-1.0;
        resultat.p2.lig = fi.bg.lig-1.0;
    }

    resultat.p1.col =  cp_resultat.p1.col  - fi.bg.col;
    resultat.p1.lig   = cp_resultat.p1.lig  - fi.hd.lig;

    resultat.p2.col   =   cp_resultat.p2.col - fi.bg.col;
    resultat.p2.lig   =  cp_resultat.p2.lig - fi.hd.lig;

    return resultat; // Renvoie le segment découpé selon la fenêtre réelle
}

///////////////////////////////////////////
// Fonction principale d'affichage d'exercise 3
///////////////////////////////////////////
void AffichagePrincipal_EXO3 ()
{

    TCouleur couleurContour = {255, 0, 0};        // Couleur du contour de la fenêtre image (rouge)
    TCouleur colorPoint = {255, 255, 0};          // Couleur de dessin des points
    TCouleur couleurSegment = {200, 150, 250};    // Couleur de dessin des segments

    // Affichage du contour de la fenêtre image (les 4 côtés) en utilisant le dessin de segments image et la couleurContour
    int minDim = HAUTEUR;
    if (minDim > LARGEUR)
        minDim = LARGEUR;
    TFenetreImage fi = { {MARGE, minDim-MARGE}, {minDim-MARGE,MARGE} };

    // Affichage les contours d'images
    DessineContoursImage(fi, couleurContour); //appel a la fonction DesineContoursImage

    // Affichage d'un triangle dans l'image
    TPointImage p1 = {10, 10};
    TPointImage p2 = {550, 300};
    TPointImage p3 = {375, 500};
    // À COMPLÉTER

    DessineTriangleFenetre(p1,p2,p3,couleurSegment,fi); //appel a la fonction DessineTriangleFenetre

    // Affichage d'un triangle dans l'image
    TPointImage q1 = {182, 486};
    TPointImage q2 = {791, 258};
    TPointImage q3 = {106, -46};

    DessineTriangleFenetre(q1,q2,q3,couleurSegment,fi); //appel a la fonction DessineTriangleFenetre


    // Affichage les segments découpés du triangle (q1,q2,q3) dans l'image

    TSegmentImage premierSegment = {q1,q2};
    TSegmentImage deuxiemeSegment = {q2,q3};
    TSegmentImage troisiemeSegment = {q3,q1};

    premierSegment = DecoupageSegmentImage(premierSegment, fi);
    deuxiemeSegment= DecoupageSegmentImage(deuxiemeSegment, fi);
    troisiemeSegment = DecoupageSegmentImage(troisiemeSegment, fi);


    DessineSegmentFenetre(premierSegment.p1, premierSegment.p2, couleurContour,fi);
    DessineSegmentFenetre(deuxiemeSegment.p1, deuxiemeSegment.p2, couleurContour,fi);
    DessineSegmentFenetre(troisiemeSegment.p1, troisiemeSegment.p2, couleurContour,fi);

    // Mise à jour de l'affichage de la fenêtre SDL (hors cadre du cours)
    SDL_Flip(fenetre);
}

/******************************************/
/*              EXERCICE 4                */
/******************************************/
///////////////////////////////////////////
// Dessiner d'un triangle plein avec le dessous plat
///////////////////////////////////////////
void DessineTrianglePleinDessousPlat(TPointImage p1, TPointImage p2, TPointImage p3, TCouleur coul, TFenetreImage fi)
{
    double invPente1 = (double)(p2.col - p1.col) / (p2.lig - p1.lig); 
    double invPente2 = (double)(p3.col - p1.col) / (p3.lig - p1.lig);
    double b1 = 0.0;
    double b2 = 0.0;

   //Calcul de b1 par rapport a invPente1
    if(invPente1 != 0)
           {
        b1 = p2.lig - (1/invPente1) * p2.col;
           }
   //Calcul de b2 par rapport a invPente2
    if(invPente2 != 0)
           {
        b2 =  p3.lig - (1/invPente2) * p3.col;
           }

    double colGauche = p1.col;
    double colDroite = p1.col;

TPointImage gauche, droite;

int ligneParcours = p1.lig;
    while ( ligneParcours <= p2.lig )
    {
        // À COMPLÉTER
        
        gauche.col = (int)colGauche;
        gauche.lig = ligneParcours;
        droite.col = (int)colDroite;
        droite.lig =  ligneParcours;
        DessineSegmentFenetre(gauche,droite,coul,fi);
        
        if(invPente1 == 0)
        {
            colGauche = p2.col;
            colDroite = (ligneParcours - b2) * invPente2;
        }

        if(invPente2 == 0)
        {
            colDroite = p3.col;
            colGauche = (ligneParcours - b1) * invPente1;
        }
        
       if(invPente1 !=0 && invPente2 !=0)
        {
            colGauche = (ligneParcours - b1) * invPente1;
            colDroite = (ligneParcours - b2) * invPente2;
        }

     ligneParcours++;

    }
}

///////////////////////////////////////////
// Dessiner d'un triangle plein avec le dessus plat
///////////////////////////////////////////
void DessineTrianglePleinDessusPlat(TPointImage p1, TPointImage p2, TPointImage p3, TCouleur coul, TFenetreImage fi)
{
    double invPente1 = (double)(p3.col - p1.col) / (p3.lig - p1.lig);
    double invPente2 = (double)(p3.col - p2.col) / (p3.lig - p2.lig);

    double b1 = 0.0;
    double b2 = 0.0;
 
    //calcul de b1 par rapport a invPente1
    if(invPente1 != 0)
    {
        b1 = p1.lig - (1/invPente1) * p1.col;
    }
    
    //calcul de b2 par rapport a invPente2
    if(invPente2 != 0)
    {
        b2 =  p2.lig - (1/invPente2) * p2.col;
    }


    double colGauche = p3.col;
    double colDroite = p3.col;

    TPointImage gauche, droite;

    int ligneParcours = p3.lig;

    while( ligneParcours > p1.lig )
    {
        // À COMPLÉTER
        // ...
        gauche.col = (int)colGauche;
        gauche.lig = ligneParcours;
        droite.col = (int)colDroite;
        droite.lig =  ligneParcours;
        DessineSegmentFenetre(gauche,droite,coul,fi);

        if(invPente1 !=0 && invPente2 !=0)
        {
            colGauche = (ligneParcours - b1) * invPente1;
            colDroite = (ligneParcours - b2) * invPente2;
        }

        if(invPente1 == 0)
        {
            colGauche = p1.col;
            colDroite = (ligneParcours - b2) * invPente2;
        }

        if(invPente2 == 0)
        {
            colDroite = p2.col;
            colGauche = (ligneParcours - b1) * invPente1;
        }

      ligneParcours--;
    }
}

///////////////////////////////////////////
// Trier les sommets du triangle par ligne-coordonnées
///////////////////////////////////////////
void trieSommets(TPointImage p1, TPointImage p2, TPointImage p3, int* min, int* mid, int* max)
{
    // Trie les les sommets du triangle par ligne-coordonnées,
    // et stocke dans les variables min,mid et max l'indice (1,2 ou 3) des points en l'ordre

    // chercher le point ayant la plus petite ligne-coordonée
    // À COMPLÉTER
    // ...

    if(( p1.lig- p2.lig) < 0 && (p1.lig - p3.lig) < 0)
    {
        *min = 1;

    }
    else
    {
        if(( p2.lig- p1.lig) < 0 && (p2.lig - p3.lig) < 0)
        {
            *min = 2;
        }
        else
        {

            if(( p3.lig- p1.lig) < 0 && (p3.lig - p2.lig) < 0)
            {
                *min = 3;
            }
        }
    }

    // chercher le point ayant la plus grand ligne-coordonée
    // À COMPLÉTER
    // ...

    if(( p1.lig- p2.lig) > 0 && (p1.lig - p3.lig) > 0)
    {
        *max = 1;

    }
    else
    {
        if(( p2.lig- p1.lig) > 0 && (p2.lig - p3.lig) > 0)
        {
            *max = 2;
        }
        else
        {

            if(( p3.lig- p1.lig) > 0 && (p3.lig - p2.lig) > 0)
            {
                *max = 3;
            }
        }
    }

    if((*min == 2 && *max == 3) || (*min == 3 && *max == 2))
        {
            *mid = 1;
        }
    
    else
    {
        if((*min == 1 && *max == 3) || (*min == 3 && *max == 1))
            {
                *mid = 2;

            }
        
        else
           {         
            if((*min == 1 && *max == 2) ||  (*min == 2 && *max == 1))
               {

               *mid = 3;
               }

           }

    }
 }

///////////////////////////////////////////
// Dessiner d'un triangle plein
///////////////////////////////////////////
    void DessineTrianglePleinFenetre(TPointImage p1, TPointImage p2, TPointImage p3, TCouleur coul, TFenetreImage fi)
    {
        TPointImage p1c,p2c,p3c;

        // Trie les points p1, p2 et p3 puis les stocke en l'ordre dans p1c,p2c et p3c grâce à la fonction trieSommets
        // À COMPLÉTER
        // ...
        int min, mid, max;

        trieSommets(p1,p2,p3, &min, &mid, &max);

       //calcul de p1c par rapport a min
       if (min==1)
          {
	    p1c=p1;
          }
       else if (min==2)
          {
            p1c = p2;
          }
       else if (min==3)
          {
           p1c = p3;
	  }

        //calcul de p2c par rapport a mid
	if (mid==1)
          {
	    p2c=p1;
          }
       else if (mid==2)
          {
            p2c = p2;
          }
       else if (mid==3)
          {
           p2c = p3;
	  }
        
       //calcul de p3c par rapport a max
      if (max==1)
          {
	    p3c=p1;
          }
       else if (max==2)
          {
            p3c = p2;
          }
       else if (max==3)
          {
           p3c = p3;
	  }

        // Vérifie si c'est un triangle avec le dessous plat
        if (p2c.lig == p3c.lig)
        {
            // À COMPLÉTER
            DessineTrianglePleinDessousPlat(p1c,p2c,p3c,coul,fi);
        }
        // Vérifie si c'est un triangle avec le dessus plat
        else if (p1c.lig == p2c.lig)
        {
            // À COMPLÉTER
            DessineTrianglePleinDessusPlat(p1c,p2c,p3c,coul,fi);
        }
        // Cas géneral - coupe le triangle en deux parties : dessous plat et dessus plat
        else
        {
            // À COMPLÉTER
             double invPente = (double)(p3c.col - p1c.col) / (p3c.lig - p1c.lig);

            double b = 0.0;

            TPointImage p4c;

    if(invPente == 0)
        {
            p4c.lig = p2c.lig;
            p4c.col = p3c.col;
        }
    if(invPente != 0)
    {
        b = p1c.lig - (1/invPente) * p1c.col;
        p4c.lig = p2c.lig;
        p4c.col = (p4c.lig - b) * invPente;
    }

         DessineTrianglePleinDessousPlat(p1c,p2c,p4c,coul,fi);
         DessineTrianglePleinDessusPlat(p2c,p4c,p3c,coul,fi);

        }
    }

///////////////////////////////////////////
// Fonction principale d'affichage d'exercise 4
///////////////////////////////////////////
    void AffichagePrincipal_EXO4 ()
    {
        TCouleur couleurContour = {255, 0, 0};        // Couleur du contour de la fenêtre image (rouge)
        TCouleur colorPoint = {255, 255, 0};          // Couleur de dessin des points
        TCouleur couleurSegment = {200, 150, 250};    // Couleur de dessin des segments
        TCouleur bordblanche = {255, 255, 255};    //couleur contour blanche triangle

        // Affichage du contour de la fenêtre image (les 4 côtés) en utilisant le dessin de segments image et la couleurContour
        int minDim = HAUTEUR;
        if (minDim > LARGEUR)
            minDim = LARGEUR;
        TFenetreImage fi = { {MARGE, minDim-MARGE}, {minDim-MARGE,MARGE} };

        // Affichage les contours d'images
        // À COMPLÉTER
        // ...

        DessineContoursImage(fi, couleurContour);

        // Affichage d'un triangle avec le bas plat dans l'image
        TPointImage p11 = {100, 100};
        TPointImage p12 = {200, 300};
        TPointImage p13 = {100, 300};
        // À COMPLÉTER
        // ...

        DessineTrianglePleinDessousPlat(p11,p12,p13,colorPoint,fi);
        DessineTriangleFenetre(p11, p12, p13, bordblanche, fi);

        // Affichage d'un triangle avec le haut plat dans l'image
        TPointImage p21 = {220, 100};
        TPointImage p22 = {550, 100};
        TPointImage p23 = {475, 200};
        // À COMPLÉTER
        // ...
        DessineTrianglePleinDessusPlat(p21,p22,p23,colorPoint,fi);
        DessineTriangleFenetre(p21, p22, p23, bordblanche, fi);
        

        // Affichage d'un triangle plein dans l'image
        TPointImage p31 = {300, 400};
        TPointImage p32 = {550, 300};
        TPointImage p33 = {375, 600};
        // À COMPLÉTER
        // ...

        DessineTrianglePleinFenetre(p31,p32,p33,colorPoint,fi);
        DessineTriangleFenetre(p31, p32, p33, bordblanche, fi);
        // Mise à jour de l'affichage de la fenêtre SDL (hors cadre du cours)
        SDL_Flip(fenetre);
    }


///////////////////////////////////////////
// Gestion des touches du clavier pour les interactions éventuelles
///////////////////////////////////////////
    char GestionEvts(SDL_Event *evt)
    {
        char ret = 0; // Valeur de retour de la fonction (0 par défaut)
        TCouleur Vert = {0, 255, 0}; // Couleur verte

        switch (evt->type)  // Types d'événements pris en compte
        {
        case SDL_QUIT:
            ret = 1;
            break;
        case SDL_KEYDOWN:   // Touche enfoncée
            switch (evt->key.keysym.sym)
            {
            case SDLK_ESCAPE:
                ret = 1;
                break;
            default:
                break;
            }
            break;
        case SDL_KEYUP:     // Touche relâchée
            switch (evt->key.keysym.sym)
            {
            case SDLK_BACKSPACE:
                EffacerTout();
                break;
            case 'q':
                ret = 1;
                break;
            case ' ':
                EffacerTout();
                EXO = (EXO + 1)%4;
                break;
            default:
                break;
            }
            break;
        case SDL_MOUSEBUTTONDOWN: // Clic souris
            ColoriePixel(evt->button.x, evt->button.y, Vert); // Coloriage en vert du pixel sous la souris
            SDL_Flip(fenetre); // Mise à jour de l'affichage de la fenêtre SDL (hors cadre du cours)
            break;
        }

        return ret;
    }

///////////////////////////////////////////
// Fonction de lancement du programme
///////////////////////////////////////////
    int main(int argc, char **argv)
    {
        char fini = 0; // Indique si le programme est fini ou non
        SDL_Event evt; // Événement SDL (hors cadre du cours)
        Uint32 configuration; // Configuration de la fenêtre SDL (hors cadre du cours)

        // Initialisation Vidéo SDL (hors cadre du cours)
        if (SDL_Init(SDL_INIT_VIDEO) < 0 ) return 1;

        // Création fenêtre SDL (hors cadre du cours)
        configuration  = SDL_HWSURFACE;  // Spécification du type de fenêtre SDL
        //  configuration |= SDL_FULLSCREEN; // (hors cadre du cours)
        if (!(fenetre = SDL_SetVideoMode(LARGEUR, HAUTEUR, PROF, configuration)))
        {
            SDL_Quit();
            return 1;
        }


        // Gestion des événements
        while(!fini)  // Boucle principale du programme (tant que non terminé)
        {
            // Affichage
            if(EXO==0)
                AffichagePrincipal_EXO1();
            else if(EXO==1)
                AffichagePrincipal_EXO2();
            else if(EXO==2)
                AffichagePrincipal_EXO3();
            else if(EXO==3)
                AffichagePrincipal_EXO4();
            while(SDL_PollEvent(&evt))  // Gestion des événements (hors cadre du cours)
            {
                fini = GestionEvts(&evt);
            }
        }

        // Terminaison SDL (hors cadre du cours)
        SDL_Quit();

        // Fin du programme
        return 0;
    }
