#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv/cvaux.hpp>

#include <stdio.h>
#include <stdlib.h>

using namespace std;
using namespace cv;

int main()
{
    // À COMMENTER LA SIGNIFICATION DES VARIABLES
    // ...
    // Variables du programme
    CvCapture *capture = 0; //variable capture correspond au flux vidéo récupéré par la webcam
    IplImage  *image = 0; // image à un instant t du flux vidéo.
    IplImage *frame = 0; // image sequentielle du flux video

    int key = 0; //variable stockant la touche keyboard pressee par le user et est utilise dans la fonction cvWaitKey qui elle meme permet de marquer une pause dans le programme en attendant que l'utilisateur appuie sur une touche du clavier.
    int option = 0; //variable de gestion du menu du programme permettant de choisir les differentes exercices

    capture = cvCaptureFromCAM(0); //initialisation de la variable capture 
    if (!capture) //Vérifier si l'ouverture du flux est ok
        return -1;
    

    printf("Chosissez une option pour lancer le programme\n\n");
    printf("1. Maquer le pattern.\n");
    printf("2. Afficher une image sur le pattern.\n");
    printf("3. Afficher un vidéo-clip sur pattern.\n");
    printf("4. Poser une repère orthogonal 3D sur le pattern.\n\n");
    printf("Votre choice : ");
    scanf("%d",&option);

    // Quitter une entrée non valide
    if(!(option>=1 && option<=4)) //test sur la variable option
    {
        printf("Invalid selection."); //si l'entier choisi est <1 && >4
        return -1;
    }

    // Télécharger l'image à afficher sur le pattern (option 2)
    IplImage *pic = cvLoadImage("FlagVietnam.jpg"); //la fonction cvLoadImage ouvre l'image ("Flagvietnam.jpg") qui est passe en argument, et retourne un IplImage* contenant ses données (pic).
    IplImage* blank_pic  = cvCreateImage(cvGetSize(pic), 8, 3); //creation d'une image vide ayant les memes proprietes en terme de dimension que "pic"

    // Télécharger le video à afficher sur le pattern (option 3)
    CvCapture* vid = cvCreateFileCapture("trailer.avi"); //Alloue et initialise la structure CvCapture pour lire le flux vidéo à partir du fichier spécifié qui est dans notre cas "trailer.avi"
    if (!vid)
        return -1;

    // Créer la fenetre
    int WIDTH=1280, HEIGHT=720;
    cvNamedWindow("AR application",CV_WINDOW_NORMAL);//CV_WINDOW_AUTOSIZE
    cv::resizeWindow("AR application", WIDTH, HEIGHT);

    // Information du chessboard pattern : 6 x 5 carrés, et 5 x 4 = 20 coins
    int b_width  = 5;
    int b_height = 4;
    int b_squares = 20;
    CvSize b_size = cvSize(b_width, b_height);

    // Variables pour la détection des coins du chessboard
    CvMat* warp_matrix = cvCreateMat(3,3,CV_32FC1);
    CvPoint2D32f* corners = new CvPoint2D32f[ b_squares ];
    int corner_count;

    // Variables de 3D objet et les matrices intrinsèques de la caméra
    Mat camMat(3, 3, CV_64FC1);
    Mat distCoeffs(4, 1, CV_64FC1);
    Mat rVec(3, 1, CV_64FC1);
    Mat tVec(3, 1, CV_64FC1);

    // Créer les points d'objet (les points 3D des coins du chessboard 5x4)
    // Comme (0,0,0), (1,0,0), (2,0,0) ....,(4,3,0)
    vector<Point3d> obj;
    // À COMPLÉTER
    obj.push_back(Point3d(0, 0, 0));
    obj.push_back(Point3d(0, 4, 0));
    obj.push_back(Point3d(3, 4, 0));
    obj.push_back(Point3d(3, 0, 0));


    // Points d'axis pour dessiner
    vector<Point3d> axis; // Points de repère 3D à affichier (option 4)
    vector<Point2d> axis_im; // Points projetés des points de repère 3D vers le plan d'image
    axis.push_back(Point3d(0,0,0));
    axis.push_back(Point3d(0,3,0));
    axis.push_back(Point3d(3,0,0));
    axis.push_back(Point3d(0,0,3));

    // Programme principale
    key=cvWaitKey(1);
    image = cvQueryFrame(capture);
    IplImage* gray = cvCreateImage(cvGetSize(image), image->depth, 1);
    IplImage *warp_pic = cvCreateImage(cvGetSize(image), 8, 3);
    IplImage *warp_blank = cvCreateImage(cvGetSize(image), 8, 3);
    while(key!='q')
    {
        image = cvQueryFrame(capture);
        if(!image) break;

        int found = cvFindChessboardCorners(image, b_size, corners, &corner_count,CV_CALIB_CB_ADAPTIVE_THRESH | CV_CALIB_CB_FILTER_QUADS);
        cvCvtColor(image, gray, CV_BGR2GRAY);
        if(found!=0)
        {
            cvFindCornerSubPix(gray, corners, corner_count,  cvSize(11,11),cvSize(-1,-1),cvTermCriteria(CV_TERMCRIT_EPS+CV_TERMCRIT_ITER, 30, 0.1));
            if(corner_count == b_squares)
            {
                if(option == 1)
                {
                    CvPoint p[4];
                    // 1. Coins de chessboard detecté
                    p[0].x=(int)corners[0].x;
                    p[0].y=(int)corners[0].y;
                    p[1].x=(int)corners[4].x;
                    p[1].y=(int)corners[4].y;
                    p[2].x=(int)corners[19].x;
                    p[2].y=(int)corners[19].y;
                    p[3].x=(int)corners[15].x;
                    p[3].y=(int)corners[15].y;

                    // 2. Dessiner un cadre autour du pattern (chessboard) detecté (option 1)
                    cvLine(image, p[0], p[1], CV_RGB(255,0,0),2);
                    cvLine(image, p[1], p[2], CV_RGB(0,255,0),2);
                    cvLine(image, p[2], p[3], CV_RGB(0,0,255),2);
                    cvLine(image, p[3], p[0], CV_RGB(255,255,0),2);

                    // 3. Afficher l'image de résultats
                    cvShowImage("AR application", image);
                }
                else if(option == 2)
                {
                    CvPoint2D32f p[4];
                    CvPoint2D32f q[4];

                    cvZero(blank_pic);
                    cvNot(blank_pic,blank_pic);
                    cvZero(warp_pic);
                    cvZero(warp_blank);

                    // 1. Points source (coins de chessboard) pour calculer la matrice perspective
                    // À COMPLÉTER
                q[0].x = (int) pic->width * 0;
		q[0].y = (int) pic->height * 0;
		q[1].x = (int) pic->width;
		q[1].y = (int) pic->height * 0;

		q[2].x = (int) pic->width;
		q[2].y = (int) pic->height;
		q[3].x = (int) pic->width * 0;
		q[3].y = (int) pic->height;

                    // 2. Points de destination (coins de chessboard détectés sur l'image) pour calculer la matrice perspective
                    // À COMPLÉTER
                    p[0].x=(int)corners[0].x;
                    p[0].y=(int)corners[0].y;
                    p[1].x=(int)corners[4].x;
                    p[1].y=(int)corners[4].y;
                    p[2].x=(int)corners[19].x;
                    p[2].y=(int)corners[19].y;
                    p[3].x=(int)corners[15].x;
                    p[3].y=(int)corners[15].y;

                    // 3. Calculater la matrice perspective avec cvGetPerspectiveTransform
                    // À COMPLÉTER
                    cvGetPerspectiveTransform(q, p, warp_matrix);

                    // 4. Appliquer la transformation perspective à l'image avec cvWarpPerspective
                    // À COMPLÉTER
                    cvWarpPerspective(pic, warp_blank, warp_matrix);
                    cvWarpPerspective(blank_pic, warp_pic, warp_matrix);

                    // 5. Combiner l'image perspective avec l'image capturé de la caméra avec cvAnd et cvOr
                    // À COMPLÉTER
                    cvNot(warp_pic, warp_pic);
                    cvAnd(warp_pic,image,warp_pic);
                    cvOr(warp_pic,warp_blank,image);

                    // 6. Afficher l'image de résultats cvShowImage
                    // À COMPLÉTER
                    cvShowImage("AR application", image);

                }
                else if(option == 3)
                {
                    CvPoint2D32f p[4];
                    CvPoint2D32f q[4];
               		
                     blank_pic = cvCreateImage( cvGetSize(image), 8, 3);

                    cvZero(blank_pic);
	            cvNot(blank_pic, blank_pic);
                    cvZero(warp_pic);
                    cvZero(warp_blank);

                    // 1. Points source
                    // À COMPLÉTER
                q[0].x = (int) blank_pic->width * 0;
		q[0].y = (int) blank_pic->height * 0;
		q[1].x = (int) blank_pic->width;
		q[1].y = (int) blank_pic->height * 0;

		q[2].x = (int) blank_pic->width;
		q[2].y = (int) blank_pic->height;
		q[3].x = (int) blank_pic->width * 0;
		q[3].y = (int) blank_pic->height;

                    // 2. Points de destination
                    // À COMPLÉTER
                    p[0].x=(int)corners[0].x;
                    p[0].y=(int)corners[0].y;
                    p[1].x=(int)corners[4].x;
                    p[1].y=(int)corners[4].y;
                    p[2].x=(int)corners[19].x;
                    p[2].y=(int)corners[19].y;
                    p[3].x=(int)corners[15].x;
                    p[3].y=(int)corners[15].y;

                    // 3. Charger le prochain frame du video pour afficher sur le pattern (option 2)
                    // À COMPLÉTER
          
		frame = cvQueryFrame(vid);
                if (!frame)
                printf("error frame");
                    
                    // 4. Calculater la matrice perspective
                    // À COMPLÉTER
                    cvGetPerspectiveTransform(q, p, warp_matrix);

                    // 5. Appliquer la transformation perspective au frame
                    // À COMPLÉTER
                    cvWarpPerspective(frame, warp_pic, warp_matrix);
                    cvWarpPerspective(blank_pic, warp_blank, warp_matrix);

                    // 6. Combiner le frame perspective avec l'image capturé de la caméra avec cvAnd et cvOr
                    // À COMPLÉTER
                    cvNot(warp_blank, warp_blank); 
                    cvAnd(warp_blank,image,warp_blank);
                    cvOr(warp_blank,warp_pic,image);

                    // 7. Afficher l'image de résultats
                    // À COMPLÉTER
                    cvShowImage("AR application", image);
                }
                else
                {
                    // Paramètres intrinsèques de la caméra
                    double k1=0.0196015295, k2=0.5051702857, p1=-0.0206646156, p2=0.0092172595;
                    double fx=1185.559570, fy=1183.471069, x0=647.333069, y0=284.717743;

                    // 1. Charger la matrice de caméra et les coefficients de distorsion
                    // À COMPLÉTER
                    camMat = (Mat1d(3,3) << fx, 0, x0, 0, fy, y0, 0, 0, 1);
                    distCoeffs = (Mat1d(1, 4) << k1, k2, p1, p1);
                    // 2. Télécharger les points de destination (coins de chessboard télécharger)
                    // À COMPLÉTER
                    vector<Point2d> janwvle;
                    janwvle.push_back(Point2d(corners[15].x, corners[15].y));
                    janwvle.push_back(Point2d(corners[19].x, corners[19].y));
                    janwvle.push_back(Point2d(corners[4].x, corners[4].y));
                    janwvle.push_back(Point2d(corners[0].x, corners[0].y));

                    // 3. Trouver les vecteurs de rotation et de traduction en utilisant la fonction solvePnPRansac
                    // À COMPLÉTER
                    solvePnPRansac(obj, janwvle, camMat, distCoeffs, rVec, tVec);

                    // 4. Projeter les points 3D d'axis vers le plan image
                    // À COMPLÉTER
                    projectPoints(axis, rVec, tVec, camMat, distCoeffs, axis_im);

                    // 5. Dessiner les points projettés sur l'image
                    // À COMPLÉTER
                    cvLine(image, axis_im[0], axis_im[1], CV_RGB(0, 255, 0), 2);
                    cvLine(image, axis_im[0], axis_im[2], CV_RGB(255, 0, 0), 2);
                    cvLine(image, axis_im[0], axis_im[3], CV_RGB(0, 0, 255), 2);

                    // 6. Afficher l'image de résultats
                    // À COMPLÉTER
                    cvShowImage("AR application", image);
                }
            }
            else
            {
                // Afficher l'image grise lorsque le motif n'est pas détecté
                cvShowImage("AR application", gray);
            }
        }
        else
            cvShowImage("AR application", image);
        key = cvWaitKey(1);
    }

    // Libèrer la mémoire et termine le programme
    cvDestroyWindow("AR application");
    cvReleaseCapture(&vid);
    cvReleaseMat(&warp_matrix);
    cvReleaseCapture(&capture);
    cvReleaseImage(&image);
    cvReleaseImage(&gray);
    cvReleaseImage(&pic);
    cvReleaseImage(&blank_pic);
    cvReleaseImage(&warp_pic);

    return 0;
}
