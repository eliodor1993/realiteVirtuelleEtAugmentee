//Fichier  : reader.cpp
//Author : Phuc NGO
//Date : 15/12/2015
//Programme : Lecture des fichiers obj
//Modification apportee par: ELIODOR Ednalson Guy Mirlin - P21
//Date : 01/18/2017

#include "reader.h"
#include<sstream>
#include<stdlib.h>

using namespace std;

Reader::Reader()
{
    nbSommet = 0;
    for(int i = 0; i < MAX_SOMMET; i++ ) {
        sommet[i][0] = 0;
        sommet[i][1] = 0;
        sommet[i][2] = 0;
    }

    for(int i = 0; i < MAX_COULEUR; i++ ) {
        couleur[i][0] = 0;
        couleur[i][1] = 0;
        couleur[i][2] = 0;
    }

    nbFacette=0;
    for(int i = 0; i < MAX_FACETTE; i++ ) {
        facette[i].p1 = 0;
        facette[i].p2 = 0;
        facette[i].p3 = 0;
        facette[i].c1 = 0;
        facette[i].c2 = 0;
        facette[i].c3 = 0;
    }
}

Reader::~Reader()
{

}

void Reader::load(string filename)
{
    ifstream file;
    file.open(filename.c_str());
    if (file.fail()) {cout<<"Error file"<<endl; return;}
    string str;

    // Les lignes de sommets
    while(!file.eof())
    {
        getline(file,str);
        if(str[0] == 'v')
            break;
    }

    int v = 0;
    while(str[0] == 'v') {
        int i = 1;
        while(!file.eof())
        {
            // À COMPLETER
                stringstream ssomm;
                ssomm << str.substr(2);

                ssomm >> sommet[v][0];
                printf(" %.2f ", sommet[v][0]);
		ssomm >> sommet[v][1];
                printf(" %.2f ", sommet[v][1]);
		ssomm >> sommet[v][2];
                printf(" %.2f \n ", sommet[v][2]);
		break;
        }
        v++;
        getline(file, str);
    }
    nbSommet = v;
    cout<<"************************************ \n ";
    

    // Les lignes de couleurs
    while(!file.eof())
    {
        getline(file,str);
        if(str[0] == 'v' && str[1] == 'n')
            break;
    }

    v = 0;
    while(str[0] == 'v' && str[1] == 'n') {
        int i = 2;
        while(!file.eof())
        {
            // À COMPLETER
                stringstream ssom;
		ssom << str.substr(3);

		ssom >> couleur[v][0];
                printf(" %.2f ", couleur[v][0]);
		ssom >> couleur[v][1];
                printf(" %.2f ", couleur[v][1]);
		ssom >> couleur[v][2];
                printf(" %.2f \n", couleur[v][1]);
		break;
        }
        v++;
        getline(file, str);
    } 
    cout<<" ************************************ \n ";

    while(!file.eof())
    {
        getline(file,str);
        if(str[0] == 'f')
            break;
    }

    // Les lignes de facettes
    v = 0;
    while(str[0] == 'f') {
        int i = 1;
        while(!file.eof())
        {
            // ...
           str = str.substr(2);
		stringstream sfac;
		string separator = "//";
		size_t position = 0;
		string temp;
		while (position != -1) {

			position = str.find(separator);
			if (str.find(separator) == -1)

			{
				temp = str;

			}else{
			temp = str.substr(0, position);
			str.erase(0, position + separator.length());
			}

			

			sfac << temp << " ";


		}

		//de meme ss << ss.substr(2);
		sfac >> facette[v].p1;
		
                cout<<(facette[v].p1);
		sfac >> facette[v].c1;
		
                cout<< " "<<(facette[v].c1);
		sfac >> facette[v].p2;
		
                cout<< " "<<(facette[v].p2);
		sfac >> facette[v].c2;
		
                cout<< " "<<(facette[v].c2);
		sfac >> facette[v].p3;
		
                cout<< " "<<(facette[v].p3);
		sfac >> facette[v].c3;
		printf(" %d \n", facette[v].c3);
                

		break;
        }
        v++;
        getline(file, str);
    }
    nbFacette = v;
}

