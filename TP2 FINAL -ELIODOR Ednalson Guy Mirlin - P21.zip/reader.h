//Fichier  : reader.h
//Author : Phuc NGO
//Date : 15/12/2015
//Contenue : Lire les fichiers obj

#ifndef READER_H
#define READER_H

#include <fstream>
#include <iostream>
#include <stdio.h>
# include <GL/glut.h>

using namespace std;

// À COMMENTER
// directives de preprocesseurs, definition de constante et remplace les occurences par les constantes predefinies (c'est comme rechercher et remplacer)
#define MAX_SOMMET 10000
#define MAX_FACETTE 10000
#define MAX_COULEUR 100

struct Facette {
        int p1;
        int p2;
        int p3;
        int c1;
        int c2;
        int c3;
};

class Reader {
    public:
        GLfloat sommet[MAX_SOMMET][3];
        GLfloat couleur[MAX_COULEUR][3];
        Facette facette[MAX_FACETTE];
        int nbSommet;
        int nbFacette;

        Reader();
        ~Reader();

        void load(string filename);
};

#endif
