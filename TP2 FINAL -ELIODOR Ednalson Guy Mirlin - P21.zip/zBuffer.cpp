/*
Programme TP : Affichage 2D sur l'algo ZBuffer
*/

#include <SDL.h>
#include <math.h>
#include <stdio.h>
#include <unistd.h>
#include <stdbool.h>
#include <string>
#include "reader.h"

using namespace std;
///////////////////////////////////////////
// Fenêtre SDL
///////////////////////////////////////////
SDL_Surface *fenetre; // Fenêtre d'affichage SDL
int BytePP = 4;       // Nombre d'octets par pixel
int PROF = 32;        // Nombre de bits par pixel
int LARGEUR = 500;    // Largeur par défaut de la fenêtre
int HAUTEUR = 500;    // Hauteur par défaut de la fenêtre
int MARGE = 75;       // Marge entre bord écran et fenêtres image
int EXO = 4;          // Selection d'exercice à affichier
Reader obj;           // Objet 3D lu à partir d'un fichier obj

///////////////////////////////////////////
// Type pour une couleur
///////////////////////////////////////////
typedef unsigned char octet; // Codage d'une composante
// de base sur un octet
typedef struct {             // Structure de couleur
        octet R, V, B ;            // composée des 3 bases
} TCouleur ;                 // Nom du type couleur

///////////////////////////////////////////
// Types de points et de segments
///////////////////////////////////////////
typedef struct {             // Structure d'un point image
        int col, lig;              // Coordonnées colonne et ligne dans l'image
} TPointImage;

///////////////////////////////////////////
// Coloriage du pixel (x,y) avec la couleur C
///////////////////////////////////////////
void ColoriePixel (int x, int y, TCouleur C)
{
    // Tests SDL pour l'affichage (hors cadre du cours)
    if(!SDL_MUSTLOCK(fenetre) || SDL_LockSurface(fenetre) >= 0){
        // Tests de validité de la position (x,y) -> à l'intérieur de la fenêtre
        if(x>=0 && x<fenetre->w && y>=0 && y<fenetre->h){
            // Affichage du pixel en SDL avec la couleur spécifiée (hors cadre du cours)
            Uint8 *pixmem32 = (Uint8*) fenetre->pixels  + y * fenetre->pitch + x * BytePP;
            *(Uint32 *)pixmem32 = SDL_MapRGB(fenetre->format, C.R, C.V, C.B);
        }
    }
    // Test et action de fin d'affichage SDL (hors cadre du cours)
    if(SDL_MUSTLOCK(fenetre)){
        SDL_UnlockSurface(fenetre);
    }
}

///////////////////////////////////////////
// Colorie tous les pixels en noir ("vide" la fenêtre)
///////////////////////////////////////////
void EffacerTout ()
{
    // Tests SDL pour l'affichage (hors cadre du cours)
    if(!SDL_MUSTLOCK(fenetre) || SDL_LockSurface(fenetre) >= 0){
        SDL_FillRect(fenetre, NULL, 0x000000);
    }
    // Test et action de fin d'affichage SDL (hors cadre du cours)
    if(SDL_MUSTLOCK(fenetre)){
        SDL_UnlockSurface(fenetre);
    }
}


/******************************************/
/*        zBuffer Algorithme              */
/******************************************/
///////////////////////////////////////////
// Alloue une tableau 2D
///////////////////////////////////////////
float** AlloueTab2D(size_t lig, size_t col)
{
    float **tab;

    // À REMPLIR
    // ...

    return tab;
}

///////////////////////////////////////////
// Libère une tableau 2D
///////////////////////////////////////////
void LibereTab2D(float** tab, size_t lig)
{
    for (int i = 0; i < lig; i++)
        delete[] tab[i];
    delete[] tab;
}

///////////////////////////////////////////
// Lire les values de profondeur
///////////////////////////////////////////
float** LireProfondeurTriangle(string filename)
{
    float** depth=AlloueTab2D(HAUTEUR,LARGEUR);
    ifstream myfile (filename);

    // À REMPLIR
    // ...

    return depth;
}

float** zBufferAlgorithm( )
{
    float** zBuffer=AlloueTab2D(HAUTEUR,LARGEUR); // Tableau pour le zBuffer 
    float** zBufferColor=AlloueTab2D(HAUTEUR,LARGEUR); // Tableau de couleur associée pour le zBuffer 
    float** depth1=LireProfondeurTriangle("depth_triangle1.txt"); // Lire profondeur du 1er triangle
    float** depth2=LireProfondeurTriangle("depth_triangle2.txt"); // Lire profondeur du 2er triangle

    // À REMPLIR
    // ...

    LibereTab2D(zBuffer,HAUTEUR);
    LibereTab2D(depth1,HAUTEUR);
    LibereTab2D(depth2,HAUTEUR);
    return zBufferColor;
}

///////////////////////////////////////////
// Fonction principale d'affichage
///////////////////////////////////////////
void AffichagePrincipal_zBuffer(Reader obj,float** zBufferColor)
{
    TCouleur c1; // Couleur du triangle 1
    TCouleur c2; // Couleur du triangle 2
    TCouleur c3; // Couleur du fond

    // À REMPLIR
    // ...

    // Mise à jour de l'affichage de la fenêtre SDL (hors cadre du cours)
    SDL_Flip(fenetre);
}

///////////////////////////////////////////
// Gestion des touches du clavier pour les interactions éventuelles
///////////////////////////////////////////
char GestionEvts(SDL_Event *evt)
{
    char ret = 0; // Valeur de retour de la fonction (0 par défaut)
    TCouleur Vert = {0, 255, 0}; // Couleur verte

    switch (evt->type){ // Types d'événements pris en compte
    case SDL_QUIT:
        ret = 1;
        break;
    case SDL_KEYDOWN:   // Touche enfoncée
        switch (evt->key.keysym.sym){
        case SDLK_ESCAPE:
            ret = 1;
            break;
        case SDLK_BACKSPACE:
            EffacerTout();
            break;
        case 'q':
            ret = 1;
            break;
        default:
            break;
        }
        break;
    case SDL_MOUSEBUTTONDOWN: // Clic souris
        ColoriePixel(evt->button.x, evt->button.y, Vert); // Coloriage en vert du pixel sous la souris
        SDL_Flip(fenetre); // Mise à jour de l'affichage de la fenêtre SDL (hors cadre du cours)
        break;
    }

    return ret;
}

///////////////////////////////////////////
// Fonction de lancement du programme
///////////////////////////////////////////
int main(int argc, char **argv)
{
    Uint32 configuration; // Configuration de la fenêtre SDL (hors cadre du cours)

    // Initialisation Vidéo SDL (hors cadre du cours)
    if (SDL_Init(SDL_INIT_VIDEO) < 0 ) return 1;

    // Création fenêtre SDL (hors cadre du cours)
    configuration  = SDL_HWSURFACE;  // Spécification du type de fenêtre SDL
    if (!(fenetre = SDL_SetVideoMode(LARGEUR, HAUTEUR, PROF, configuration))){
        SDL_Quit();
        return 1;
    }

    // Charge le contenue d'un fichier d'objet 3D obj
    // À COMPLÉTER
    // ...
    
    // Appeler l'algorithm de zBuffer
    // À COMPLÉTER
    // ...

    float** zBufferColor=zBufferAlgorithm();

    // Gestion des événements
    char fini = 0; // Indique si le programme est fini ou non
    SDL_Event evt; // Événement SDL (hors cadre du cours)
    while(!fini){ // Boucle principale du programme (tant que non terminé)

        // Appeler la fonction de l'affichage
        // À COMPLÉTER
        // ...
       
        AffichagePrincipal_zBuffer(obj,zBufferColor);
        while(SDL_PollEvent(&evt)){ // Gestion des événements (hors cadre du cours)
            fini = GestionEvts(&evt);
        }
    }

    // Terminaison SDL (hors cadre du cours)
    SDL_Quit();
    // Liberation de la mémoire associée au zBuffer
    LibereTab2D(zBufferColor,HAUTEUR);
    // Fin du programme
    return 0;
}
