/*
Programme TP : Affichage 2D sur l'algo ZBuffer OpenGL
Nom & Prenom : ELIODOR Ednalson Guy Mirlin - P21
*/

# include <cstdlib>
# include <cmath>
# include <iostream>
# include <iomanip>
# include <fstream>

#include "reader.h"

using namespace std;

///////////////////////////////////////////
// Variables globales
///////////////////////////////////////////
Reader obj; // Objet 3D lu à partir d'un fichier obj
static GLfloat theta[3] = { 15.0, 0.0, 0.0 }; // Angles de rotation sur les axis pour l'évenement du clavier
static double deltaTheta = 5; // L'incrémentation de l'angle de rotation pour l'évenement du clavier
static GLfloat zoom = 1.0; // Coeffient de zoom pour l'évenement du clavier
static double axisSize = 1.3; // Longeurs des axis à Dessinener
static bool lumiere = true; // Ativation de la lumière de la scène

///////////////////////////////////////////
// Dessine un point à coordonées (x,y,z) avec la couleur c dans la scène
///////////////////////////////////////////
void DessinePoint(string texte,float x,float y,float z, float r, float g, float b)
{
    glBegin(GL_POINTS);
    glColor3f(r,g,b);
    glVertex3f(x,y,z);
    glEnd();
}

///////////////////////////////////////////
// Dessine du texte à coordonées (x,y,z) dans la scène
///////////////////////////////////////////
void DessineBitmapTexte(string texte,float x,float y,float z)
{
    glRasterPos3f(x,y,z);
    for (int i=0; i<texte.length(); i++)
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texte.at(i));
}

///////////////////////////////////////////
// Dessine des axis dans la scène
///////////////////////////////////////////
void DessineAxis (double a){
    // À COMMENTER
    // Des formes 2D et 3D peuvent etre dessinner en utilisant OpenGL, Ces formes sont contruites de PRIMITIVES.
    // glBegin :fonction openGL délimite les sommets d'un primitif ou d'un groupe de primitives similaires
    glBegin(GL_LINES); //GL_LINES : mode de glBegin traitant chaque paire de sommets comme un segment de ligne indépendant.

    glColor3f(1.0,0.0,0.0); // Definit la couleur : blue
    glVertex3f(0.0,0.0,0.0); // Definit les coordonnees des sommets
    glVertex3f(a,0.0,0.0);

    glColor3f(0.0,1.0,0.0);// Definit la couleur : green
    glVertex3f(0.0,0.0,0.0);
    glVertex3f(0.0,a,0.0);

    glColor3f(0.0,0.0,1.0);// Definit la couleur : rouge
    glVertex3f(0.0,0.0,0.0);
    glVertex3f(0.0,0.0,a);
    
    //glEnd: Appel permettant d'indiquer la fin du dessin de notre primitive ou du moins mettre fin a glbegin
    glEnd();
}

///////////////////////////////////////////
// Dessine des textes x, y et z aux buts des axis
///////////////////////////////////////////
void DessineTexteAxis(double a)
{
    // À COMPLÉTER
    DessineAxis(a); //Appel a la fonction DessineAxis
    glColor3f(1.0,0.0,0.0);
    DessineBitmapTexte("x",a,0.0,0.0);
    glColor3f(0.0,1.0,0.0);
    DessineBitmapTexte("y",0.0,a,0.0);
    glColor3f(0.0,0.0,1.0);
    DessineBitmapTexte("z",0.0,0.0,a);
}

///////////////////////////////////////////
// Dessine des triangles d'un objet 3D
///////////////////////////////////////////
void DessineTriangles ( Reader obj )
{
    // À COMMENTER
    //Dessiner triangle en :
    // Dessinant un groupe de lignes connectées, formant une chaine partant du premier vertex et s'arrêtant au deriner.
    //Dessinant un polygone convexe
    for(int id_Triangle = 0; id_Triangle<obj.nbFacette; id_Triangle++)
    {
        glColor3f(0.0,0.0,0.0);
        glBegin ( GL_LINE_LOOP );
        glVertex3fv ( obj.sommet[obj.facette[id_Triangle].p1] );
        glVertex3fv ( obj.sommet[obj.facette[id_Triangle].p2] );
        glVertex3fv ( obj.sommet[obj.facette[id_Triangle].p3] );
        glEnd ( );

        glBegin ( GL_POLYGON );
        glColor3fv ( obj.couleur[obj.facette[id_Triangle].c1] );
        glVertex3fv ( obj.sommet[obj.facette[id_Triangle].p1] );
        glColor3fv ( obj.couleur[obj.facette[id_Triangle].c2] );
        glVertex3fv ( obj.sommet[obj.facette[id_Triangle].p2] );
        glColor3fv ( obj.couleur[obj.facette[id_Triangle].c3] );
        glVertex3fv ( obj.sommet[obj.facette[id_Triangle].p3] );
        glEnd ( );
    }


}


///////////////////////////////////////////
// Initialise Opengl
///////////////////////////////////////////
void initOpenGL( ) //initialisation de notre vue 3D
{
    // À COMMENTER
    // En gros, initialisation de la vue 3D et mise en place de la luminosite

    glClearColor (0.0, 0.0, 0.0, 0.0); // Effacement ecran; fond = noir || initialisation OpenGL couleur de fond
    glShadeModel (GL_SMOOTH); // Precise a OpenGL qu'il faut adoucir les bords des polygones sinon se serait GL_FLAT
    glEnable(GL_DEPTH_TEST); //Activation du z buffer ou le test de la profondeur

    if(lumiere)
    {
        GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 }; //definitions des couleurs, valeurs par defaut avec l'utilisation de GL_LIGHT0
        GLfloat mat_shininess[] = { 50.0 };
        GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 };  //position source lumineuse
        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
        glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
        glLightfv(GL_LIGHT0, GL_POSITION, light_position);

        glEnable(GL_LIGHTING); //activation de la lumiere
        glEnable(GL_LIGHT0); //activation de la lumiere numero 1
    }
}

///////////////////////////////////////////
// Gestion des touches du clavier pour les interactions éventuelles
///////////////////////////////////////////
void GestionEvtsClavier ( unsigned char key, int x, int y )
{
    // À COMMENTER
    // Interaction entre les touches claviers de l'utilisateur et l'objet 3D dans la fenetre console
    if(key == 'q' || key == 'Q' || key == 27)
        exit(0); //Quitter le programme
    if(key == 'a')//rotation
        theta[0] = (theta[0] + deltaTheta) > 360 ? (theta[0] + deltaTheta) - 360 : (theta[0] + deltaTheta);
    else if(key == 'b') //rotation
        theta[1] = (theta[1] + deltaTheta) > 360 ? (theta[1] + deltaTheta) - 360 : (theta[1] + deltaTheta);
    else if(key == 'c') //rotation 
        theta[2] = (theta[2] + deltaTheta) > 360 ? (theta[2] + deltaTheta) - 360 : (theta[2] + deltaTheta);
    else if(key == 'd')
        zoom += 0.1; //Zoom in
    else if(key == 'e')
        zoom -= 0.1; //Zoom out
    glutPostRedisplay ( );
}

///////////////////////////////////////////
// Gestion des touches de la souris pour les interactions éventuelles
///////////////////////////////////////////
void  GestionEvtsSouris( int bouton, int state, int x, int y )
{
    // À COMMENTER
    // Action lorsque l'une des cliques de la souris est pressee
    if ( bouton == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
        printf("Comming soon ... \n"); //designe ce que doit afficher l'application en cas ou la clique gauche du souris serait pressee.
    if ( bouton == GLUT_MIDDLE_BUTTON && state == GLUT_DOWN )
        printf("Comming soon ... \n");//designe ce que doit afficher l'application en cas ou la clique milieu du souris serait pressee.
    if ( bouton == GLUT_RIGHT_BUTTON && state == GLUT_DOWN )
        printf("Comming soon ... \n");//designe ce que doit afficher l'application en cas ou la clique droite du souris serait pressee.
}

//////////////////////////////////////
//Fonction triangles
/////////////////////////////////////
void Triangles(int id_Triangle) {

	glBegin(GL_TRIANGLES);
			glColor3fv(obj.couleur[obj.facette[id_Triangle].c1-1]);
			glVertex3fv(obj.sommet[obj.facette[id_Triangle].p1-1]);
			glColor3fv(obj.couleur[obj.facette[id_Triangle].c2-1]);
			glVertex3fv(obj.sommet[obj.facette[id_Triangle].p2-1]);
			glColor3fv(obj.couleur[obj.facette[id_Triangle].c3-1]);
			glVertex3fv(obj.sommet[obj.facette[id_Triangle].p3-1]);
		glEnd();


}

void Triangles(Reader obj) {

	for (int id_Triangle = 0; id_Triangle < obj.nbFacette; id_Triangle++) {

		Triangles(id_Triangle); //dessiner triangle par triangle
	}
}
///////////////////////////////////////////
// Fonction d'affichage graphique
///////////////////////////////////////////
void Affichage( )
{
    // À COMMENTER
    
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //nettoie le color buffer (l'écran) avec les valeurs précisées par glClearColor. De même pour le depth buffer (fonction glClearDepth).
    glLoadIdentity ( ); //remplacement de la matrice courante par la matrice identité
    //gestion de la rotation
    glRotatef ( theta[0], 1.0, 0.0, 0.0 ); //Multiplication de la matrice courante par une matrice de rotation, Spécifie l'angle de rotation, en degré, specification respectivement des coordonnees x, y et z d'un vecteur
    glRotatef ( theta[1], 0.0, 1.0, 0.0 );
    glRotatef ( theta[2], 0.0, 0.0, 1.0 );
    glScalef ( zoom, zoom, zoom );// transformation des axes du repère afin de grossir, diminuer, étirer l' objet ou les objets

    // Dessine des objets 3D
    // À COMPLÉTER
   
    //Exo1.2
    //glutSolidSphere (0.7, 20, 16);
    //glutSolidTeapot(0.7);
    //glutWireCone (1.0, 2.0, 3, 4);
    //glutSolidCube (0.5);
    //glutSolidTorus(0.75, 1.5, 6, 6);

    //Exo 2
    DessineTexteAxis(1.3); //dessiner les labels des axes 
   
     //Exo 3
     DessineTriangles (obj); //appel a la fonction DessineTriangles
     
     //Exo 4
     Triangles(obj); //Appel a la fonction creee Triangles
    

    // Vide tous ces buffers, et cause l'exécution de toutes les commandes
    glFlush ();
}

///////////////////////////////////////////
// Fonction pour la redimension de la fenêtre
///////////////////////////////////////////
void reshape (int w, int h)
{
    // À COMMENTER
    // delimitation de la zone de dessin
    glViewport (0, 0, (GLsizei) w, (GLsizei) h); //Spécifie la transformation affine de w et h des coordonnées normalisées du dispositif aux coordonnées de la fenêtre.
    glMatrixMode (GL_PROJECTION);//Applique les opérations matricielles suivantes à la pile de la matrice de projection.
    glLoadIdentity();//Remplace la matrice courante par la matrice identité
    if (w <= h)
        glOrtho (-1.5, 1.5, -1.5*(GLfloat)h/(GLfloat)w,
                 1.5*(GLfloat)h/(GLfloat)w, -10.0, 10.0);
    else
        glOrtho (-1.5*(GLfloat)w/(GLfloat)h,
                 1.5*(GLfloat)w/(GLfloat)h, -1.5, 1.5, -10.0, 10.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

///////////////////////////////////////////
// Fonction de lancement du programme
///////////////////////////////////////////
int main(int argc, char** argv)
{
    // Charge le contenue d'un fichier d'objet 3D obj
    // À COMPLÉTER
    obj.load("Data/cube.obj");
    printf("nb de sommets = %d\n", obj.nbSommet);
    printf("nb de facettes = %d\n", obj.nbFacette);

    // À COMMENTER

    glutInit(&argc, argv); //Envoie les parametres du main a l'init de Glut.
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500, 500);//fixation de la longueur et de la hauteur de la fenetre.
    glutInitWindowPosition(100, 100);//positionnement de la fenetre 
    glutCreateWindow ( "Z-Buffer" ); //creer une fenetre de nom "Z-Buffer"
    initOpenGL(); //initialisation de notre vue 
    glutDisplayFunc(Affichage); //dessin de la fenetre pour la fonction affichage
    glutReshapeFunc(reshape);//redimensionnement de la fenetre
    glutMouseFunc(GestionEvtsSouris); // reference a la fonction de gestion des touches de la souris
    glutKeyboardFunc(GestionEvtsClavier); //cela fait reference a la fonction de gestion des touches 
    glutMainLoop(); //boucle infinie qui fait tourner l'application en executant la fonction affichage

    return 0;
}

